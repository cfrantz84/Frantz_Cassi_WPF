//Expressions - Wacky

//
var a = prompt ("Enter a random number", 1.0466666666667);
var b = prompt ("Now times that by 3", 3);
var c = prompt ("I hope you like pi!")
var d;
d = 1.0466666666667 * 3;
alert(d);
console.log(d)