//Expressions - Personal

//amount of fuel needed to make a trip to Oregon to visit family, at 20 miles per gallon, traveling a distance of 1737 miles.
var a = prompt ("Miles needed to travel from Sedan, KS to Prineville, OR", 1737); //miles to be traveled
var b = prompt ("Miles per gallon of fuel for vehicle", 20); //miles per gallon of fuel
var c;
c = 1737/20; //gallons of fuel needed for trip
alert(c);
console.log(c)
