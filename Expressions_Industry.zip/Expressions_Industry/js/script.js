//Expressions - Industry

//how many pixels square is the image resolution

var width = prompt ("What is the width of the image?", 682);
var height = prompt ("What is the height of the image?", 948);
var answer;
answer = 682 * 948;
alert(answer);
console.log(answer)